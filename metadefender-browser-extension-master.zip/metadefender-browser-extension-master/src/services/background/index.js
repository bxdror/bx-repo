import { Task } from "./background-task";

Task.init();
